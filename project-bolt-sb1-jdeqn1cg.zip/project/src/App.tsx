import Navbar from './components/Navbar';
import Hero from './components/Hero';
import TrustBar from './components/TrustBar';
import Work from './components/Work';
import Services from './components/Services';
import About from './components/About';
import Reviews from './components/Reviews';
import QuoteForm from './components/QuoteForm';
import Contact from './components/Contact';
import Footer from './components/Footer';
import { useScrollReveal } from './useScrollReveal';

function App() {
  useScrollReveal();

  return (
    <div className="min-h-screen bg-[#faf8f5] text-[#1c1917]">
      <Navbar />
      <main>
        <Hero />
        <TrustBar />
        <Work />
        <Services />
        <About />
        <Reviews />
        <QuoteForm />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}

export default App;

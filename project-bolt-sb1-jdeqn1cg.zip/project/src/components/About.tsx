import { CheckCircle2, Quote } from 'lucide-react';

const POINTS = [
  'Family-owned & locally operated in Tarneit',
  'Direct communication with the builder, every time',
  'Premium materials sourced from trusted suppliers',
  'On-time delivery and clean, respectful installation',
];

export default function About() {
  return (
    <section id="about" className="bg-[#f5efe6] py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <div className="grid items-center gap-12 lg:grid-cols-2 lg:gap-20">
          {/* Image stack */}
          <div className="reveal relative">
            <div className="overflow-hidden rounded-[2rem] shadow-2xl">
              <img
                src="/images/kitchen-overview/WhatsApp_Image_2026-07-14_at_11.13.44_AM_(1).jpeg"
                alt="Finished kitchen by Easyhome Cabinetry"
                loading="lazy"
                className="aspect-[4/5] w-full object-cover"
              />
            </div>
            <div className="absolute -bottom-8 -right-4 w-44 overflow-hidden rounded-2xl border-4 border-[#f5efe6] shadow-xl sm:w-56 sm:-right-8">
              <img
                src="/images/tv-wall/WhatsApp_Image_2026-07-14_at_11.13.43_AM_(1).jpeg"
                alt="TV wall detail"
                loading="lazy"
                className="aspect-square w-full object-cover"
              />
            </div>
            {/* Floating badge */}
            <div className="absolute -left-4 top-8 rounded-2xl bg-[#14110d] px-5 py-4 text-white shadow-xl sm:-left-8">
              <span className="font-display text-3xl font-semibold text-[#e6c860]">5.0</span>
              <div className="mt-0.5 flex gap-0.5">
                {[...Array(5)].map((_, i) => (
                  <span key={i} className="text-[#e6c860]">★</span>
                ))}
              </div>
              <span className="mt-1 block text-[10px] uppercase tracking-wider text-stone-400">8 Reviews</span>
            </div>
          </div>

          {/* Text */}
          <div className="reveal">
            <span className="text-xs font-bold uppercase tracking-[0.3em] text-[#b08968]">About Easyhome</span>
            <h2 className="mt-3 font-display text-4xl font-semibold leading-tight text-[#1c1917] sm:text-5xl">
              Built by hands that care about the details
            </h2>
            <div className="mt-6 space-y-4 text-stone-600">
              <p className="relative pl-6">
                <Quote size={16} className="absolute left-0 top-1.5 text-[#c9a227]" />
                Easyhome Cabinetry is a Tarneit-based cabinet maker led by Rohit and a small,
                experienced team. We design, build and install custom joinery for homes across
                Melbourne's western suburbs.
              </p>
              <p>
                We keep the process simple: one team, one point of contact, and a commitment to
                quality that shows in every hinge, joint and finish. Our 5-star reviews reflect
                the standard we hold ourselves to on every job.
              </p>
            </div>

            <ul className="mt-8 grid gap-3 sm:grid-cols-2">
              {POINTS.map((p) => (
                <li key={p} className="flex items-start gap-3 text-sm text-[#1c1917]">
                  <CheckCircle2 size={20} className="mt-0.5 shrink-0 text-[#6f4e37]" />
                  {p}
                </li>
              ))}
            </ul>

            <div className="mt-10 flex flex-wrap gap-4">
              <button
                onClick={() => document.querySelector('#quote')?.scrollIntoView({ behavior: 'smooth' })}
                className="rounded-full bg-[#14110d] px-7 py-3.5 text-sm font-semibold text-white transition-all hover:bg-[#6f4e37] hover:-translate-y-0.5"
              >
                Start your project
              </button>
              <a
                href="https://www.google.com/maps/search/?api=1&query=Easyhome+Cabinetry+36+Reunion+Parade+Tarneit+VIC+3029"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center rounded-full border border-[#6f4e37]/30 px-7 py-3.5 text-sm font-semibold text-[#6f4e37] transition-all hover:bg-[#6f4e37]/5"
              >
                Read Google reviews →
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

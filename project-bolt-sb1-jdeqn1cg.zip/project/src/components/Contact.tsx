import { MapPin, Phone, Clock, Navigation, ExternalLink } from 'lucide-react';

const CARDS = [
  {
    icon: MapPin,
    label: 'Visit the workshop',
    value: '36 Reunion Parade, Tarneit VIC 3029',
    href: 'https://www.google.com/maps/search/?api=1&query=36+Reunion+Parade+Tarneit+VIC+3029',
    cta: 'Open in Google Maps',
  },
  {
    icon: Phone,
    label: 'Call or text',
    value: '0451 600 512',
    href: 'tel:0451600512',
    cta: 'Tap to call',
  },
  {
    icon: Clock,
    label: 'Opening hours',
    value: 'Open daily · Closes 3:30 pm',
    href: null,
    cta: 'Updated by business 2 weeks ago',
  },
];

export default function Contact() {
  return (
    <section id="contact" className="bg-[#f5efe6] py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <div className="reveal mx-auto mb-14 max-w-2xl text-center">
          <span className="text-xs font-bold uppercase tracking-[0.3em] text-[#b08968]">Contact</span>
          <h2 className="mt-3 font-display text-4xl font-semibold text-[#1c1917] sm:text-5xl">
            Easy to find, easy to reach
          </h2>
          <p className="mt-4 text-stone-600">
            We're based in Tarneit and service homes across Melbourne's western suburbs.
            Pop in, call, or send a quote request — whatever suits you.
          </p>
        </div>

        <div className="grid gap-5 lg:grid-cols-3">
          {CARDS.map((c, i) => {
            const Wrapper = c.href ? 'a' : 'div';
            return (
              <Wrapper
                key={c.label}
                {...(c.href ? { href: c.href, target: '_blank', rel: 'noopener noreferrer' } : {})}
                className="reveal group flex flex-col rounded-3xl border border-[#b08968]/15 bg-white p-7 shadow-sm transition-all hover:-translate-y-1 hover:shadow-xl hover:shadow-[#b08968]/10"
                style={{ transitionDelay: `${i * 80}ms` }}
              >
                <span className="mb-4 grid h-12 w-12 place-items-center rounded-xl bg-gradient-to-br from-[#c9a227]/15 to-[#b08968]/15 text-[#6f4e37] transition-transform group-hover:scale-110">
                  <c.icon size={22} />
                </span>
                <span className="text-xs font-semibold uppercase tracking-wider text-stone-500">{c.label}</span>
                <span className="mt-1 font-display text-lg font-semibold text-[#1c1917]">{c.value}</span>
                {c.href ? (
                  <span className="mt-3 inline-flex items-center gap-1.5 text-sm font-medium text-[#b08968]">
                    {c.cta} <ExternalLink size={14} className="transition-transform group-hover:translate-x-0.5" />
                  </span>
                ) : (
                  <span className="mt-3 text-sm text-stone-400">{c.cta}</span>
                )}
              </Wrapper>
            );
          })}
        </div>

        {/* Map embed */}
        <div className="reveal mt-8 overflow-hidden rounded-3xl border border-[#b08968]/15 shadow-lg">
          <iframe
            title="Easyhome Cabinetry location map"
            src="https://www.google.com/maps?q=36+Reunion+Parade+Tarneit+VIC+3029&output=embed"
            width="100%"
            height="380"
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
            className="block w-full border-0"
          />
        </div>

        <div className="reveal mt-8 text-center">
          <a
            href="https://www.google.com/maps/dir/?api=1&destination=36+Reunion+Parade+Tarneit+VIC+3029"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 rounded-full bg-[#14110d] px-7 py-3.5 text-sm font-semibold text-white transition-all hover:bg-[#6f4e37] hover:-translate-y-0.5"
          >
            <Navigation size={16} /> Get directions
          </a>
        </div>
      </div>
    </section>
  );
}

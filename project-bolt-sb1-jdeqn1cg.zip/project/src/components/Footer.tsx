import { Phone, MapPin, Clock, Star, ArrowUp } from 'lucide-react';

export default function Footer() {
  const year = new Date().getFullYear();
  return (
    <footer className="bg-[#14110d] text-stone-300">
      {/* Marquee strip */}
      <div className="overflow-hidden border-y border-white/10 py-4 no-scrollbar">
        <div className="marquee-track flex w-max gap-8 whitespace-nowrap text-sm uppercase tracking-[0.3em] text-stone-500">
          {[...Array(2)].map((_, dup) => (
            <span key={dup} className="flex items-center gap-8">
              <span>Custom Kitchens</span><span className="text-[#c9a227]">✦</span>
              <span>Walk-in Wardrobes</span><span className="text-[#c9a227]">✦</span>
              <span>TV Wall Units</span><span className="text-[#c9a227]">✦</span>
              <span>Custom Joinery</span><span className="text-[#c9a227]">✦</span>
              <span>Made in Tarneit</span><span className="text-[#c9a227]">✦</span>
              <span>5.0 ★ Rated</span><span className="text-[#c9a227]">✦</span>
            </span>
          ))}
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-5 py-14 sm:px-8">
        <div className="grid gap-10 md:grid-cols-2 lg:grid-cols-4">
          {/* Brand */}
          <div className="lg:col-span-1">
            <div className="flex items-center gap-3">
              <span className="grid h-11 w-11 place-items-center rounded-xl bg-gradient-to-br from-[#c9a227] to-[#b08968] text-[#14110d]">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                  <rect x="3" y="4" width="18" height="16" rx="1.5" />
                  <line x1="12" y1="4" x2="12" y2="20" />
                  <line x1="3" y1="12" x2="21" y2="12" />
                </svg>
              </span>
              <div>
                <span className="block font-display text-lg font-semibold text-white">Easyhome</span>
                <span className="block text-[10px] uppercase tracking-[0.35em] text-[#c9a227]">Cabinetry</span>
              </div>
            </div>
            <p className="mt-4 max-w-xs text-sm leading-relaxed text-stone-400">
              Custom cabinetry, kitchens and wardrobes handcrafted in Tarneit, VIC.
              Built with care, finished to last.
            </p>
            <div className="mt-4 inline-flex items-center gap-2 rounded-full bg-white/5 px-3 py-1.5 text-xs">
              <Star size={14} className="fill-[#e6c860] text-[#e6c860]" />
              <span className="font-semibold text-white">5.0</span>
              <span className="text-stone-400">· 8 Google reviews</span>
            </div>
          </div>

          {/* Links */}
          <div>
            <h4 className="text-xs font-semibold uppercase tracking-wider text-white">Explore</h4>
            <ul className="mt-4 space-y-2.5 text-sm">
              {[
                ['Home', '#home'],
                ['Our Work', '#work'],
                ['Services', '#services'],
                ['Reviews', '#reviews'],
                ['Get a Quote', '#quote'],
                ['Contact', '#contact'],
              ].map(([label, href]) => (
                <li key={href}>
                  <button onClick={() => document.querySelector(href)?.scrollIntoView({ behavior: 'smooth' })} className="text-stone-400 transition-colors hover:text-[#e6c860]">
                    {label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="text-xs font-semibold uppercase tracking-wider text-white">Services</h4>
            <ul className="mt-4 space-y-2.5 text-sm text-stone-400">
              <li>Custom Kitchens</li>
              <li>Walk-in Wardrobes</li>
              <li>TV Wall Units</li>
              <li>Custom Cabinetry & Joinery</li>
              <li>Free Measure & Quote</li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-xs font-semibold uppercase tracking-wider text-white">Get in touch</h4>
            <ul className="mt-4 space-y-3 text-sm">
              <li className="flex items-start gap-3">
                <MapPin size={18} className="mt-0.5 shrink-0 text-[#c9a227]" />
                <a href="https://www.google.com/maps/search/?api=1&query=36+Reunion+Parade+Tarneit+VIC+3029" target="_blank" rel="noopener noreferrer" className="text-stone-400 transition-colors hover:text-[#e6c860]">
                  36 Reunion Parade, Tarneit VIC 3029
                </a>
              </li>
              <li className="flex items-center gap-3">
                <Phone size={18} className="shrink-0 text-[#c9a227]" />
                <a href="tel:0451600512" className="text-stone-400 transition-colors hover:text-[#e6c860]">0451 600 512</a>
              </li>
              <li className="flex items-center gap-3">
                <Clock size={18} className="shrink-0 text-[#c9a227]" />
                <span className="text-stone-400">Open · Closes 3:30 pm</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 flex flex-col items-center justify-between gap-4 border-t border-white/10 pt-6 text-sm text-stone-500 sm:flex-row">
          <p>© {year} Easyhome Cabinetry. All rights reserved.</p>
          <div className="flex items-center gap-4">
            <span>Tarneit, Victoria</span>
            <button
              onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
              className="inline-flex items-center gap-1.5 rounded-full border border-white/15 px-3 py-1.5 text-xs text-stone-300 transition-colors hover:border-[#c9a227] hover:text-[#e6c860]"
              aria-label="Back to top"
            >
              <ArrowUp size={14} /> Top
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
}

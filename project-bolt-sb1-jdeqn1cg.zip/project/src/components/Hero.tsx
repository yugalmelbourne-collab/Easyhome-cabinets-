import { Star, MapPin, Clock, ArrowRight } from 'lucide-react';

export default function Hero() {
  return (
    <section id="home" className="relative min-h-screen overflow-hidden bg-[#14110d]">
      {/* Background image collage */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 grid grid-cols-2 grid-rows-2 gap-1 opacity-40">
          <img src="/images/kitchen/WhatsApp_Image_2026-07-14_at_11.13.44_AM.jpeg" alt="Custom kitchen cabinetry" className="h-full w-full object-cover" loading="eager" />
          <img src="/images/wardrobe/WhatsApp_Image_2026-07-14_at_11.13.43_AM.jpeg" alt="Walk-in wardrobe" className="h-full w-full object-cover" loading="eager" />
          <img src="/images/tv-wall/WhatsApp_Image_2026-07-14_at_11.13.43_AM_(1).jpeg" alt="TV wall unit" className="h-full w-full object-cover" loading="eager" />
          <img src="/images/kitchen-overview/WhatsApp_Image_2026-07-14_at_11.13.44_AM_(1).jpeg" alt="Kitchen overview" className="h-full w-full object-cover" loading="eager" />
        </div>
        <div className="absolute inset-0 bg-gradient-to-b from-[#14110d]/80 via-[#14110d]/85 to-[#14110d]" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#14110d] via-transparent to-transparent" />
      </div>

      {/* Floating decorative blobs */}
      <div className="pointer-events-none absolute -left-24 top-1/3 h-72 w-72 rounded-full bg-[#c9a227]/20 blur-3xl animate-floaty-slow" />
      <div className="pointer-events-none absolute right-10 top-24 h-56 w-56 rounded-full bg-[#b08968]/20 blur-3xl animate-floaty" />

      <div className="relative z-10 mx-auto flex min-h-screen max-w-7xl flex-col justify-center px-5 pb-20 pt-32 sm:px-8">
        <div className="max-w-3xl">
          <div className="reveal mb-6 inline-flex items-center gap-2 rounded-full border border-[#c9a227]/30 bg-[#c9a227]/10 px-4 py-2 backdrop-blur-sm">
            <div className="flex">
              {[...Array(5)].map((_, i) => (
                <Star key={i} size={14} className="fill-[#e6c860] text-[#e6c860]" />
              ))}
            </div>
            <span className="text-xs font-semibold tracking-wide text-[#e6c860]">5.0 · 8 Google Reviews</span>
          </div>

          <h1 className="reveal font-display text-5xl font-semibold leading-[1.05] text-white sm:text-6xl lg:text-7xl">
            Crafted Cabinetry,
            <span className="block shimmer-text">Built for Your Home</span>
          </h1>

          <p className="reveal mt-6 max-w-xl text-lg leading-relaxed text-stone-300">
            Custom kitchens, walk-in wardrobes, and TV-wall units — handcrafted in Tarneit
            with precision, premium materials, and finishes that last a lifetime.
          </p>

          <div className="reveal mt-9 flex flex-wrap items-center gap-4">
            <button
              onClick={() => document.querySelector('#quote')?.scrollIntoView({ behavior: 'smooth' })}
              className="group inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-[#c9a227] to-[#b08968] px-7 py-4 text-base font-semibold text-[#14110d] shadow-xl shadow-[#c9a227]/25 transition-all hover:shadow-2xl hover:shadow-[#c9a227]/40 hover:-translate-y-1"
            >
              Get a Free Quote
              <ArrowRight size={18} className="transition-transform group-hover:translate-x-1" />
            </button>
            <button
              onClick={() => document.querySelector('#work')?.scrollIntoView({ behavior: 'smooth' })}
              className="inline-flex items-center gap-2 rounded-full border border-white/25 bg-white/5 px-7 py-4 text-base font-medium text-white backdrop-blur-sm transition-all hover:bg-white/10 hover:border-white/40"
            >
              View Our Work
            </button>
          </div>

          {/* Quick info strip */}
          <div className="reveal mt-12 flex flex-wrap gap-x-8 gap-y-4 text-sm text-stone-300">
            <span className="inline-flex items-center gap-2">
              <MapPin size={16} className="text-[#c9a227]" />
              36 Reunion Parade, Tarneit VIC 3029
            </span>
            <span className="inline-flex items-center gap-2">
              <Clock size={16} className="text-[#c9a227]" />
              Open · Closes 3:30 pm
            </span>
          </div>
        </div>
      </div>

      {/* Scroll cue */}
      <div className="absolute bottom-6 left-1/2 z-10 -translate-x-1/2">
        <div className="flex h-10 w-6 items-start justify-center rounded-full border-2 border-white/30 p-1.5">
          <div className="h-2 w-1 animate-bounce rounded-full bg-[#e6c860]" />
        </div>
      </div>
    </section>
  );
}

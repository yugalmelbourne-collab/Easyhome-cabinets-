import { useEffect, useState } from 'react';
import { Menu, X, Phone } from 'lucide-react';

const LINKS = [
  { label: 'Home', href: '#home' },
  { label: 'Our Work', href: '#work' },
  { label: 'Services', href: '#services' },
  { label: 'Reviews', href: '#reviews' },
  { label: 'Contact', href: '#contact' },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState('#home');

  useEffect(() => {
    const onScroll = () => {
      setScrolled(window.scrollY > 30);
      const sections = LINKS.map((l) => l.href.slice(1));
      const cur = sections.find((id) => {
        const el = document.getElementById(id);
        if (!el) return false;
        const r = el.getBoundingClientRect();
        return r.top <= 120 && r.bottom >= 120;
      });
      if (cur) setActive('#' + cur);
    };
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const go = (href: string) => {
    setOpen(false);
    const el = document.querySelector(href);
    el?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-500 ${
        scrolled
          ? 'bg-[#14110d]/90 backdrop-blur-xl shadow-[0_10px_40px_-15px_rgba(0,0,0,0.5)] py-3'
          : 'bg-transparent py-5'
      }`}
    >
      <nav className="mx-auto flex max-w-7xl items-center justify-between px-5 sm:px-8">
        <button
          onClick={() => go('#home')}
          className="group flex items-center gap-3 focus-ring rounded-lg"
          aria-label="Easyhome Cabinetry home"
        >
          <span className="grid h-11 w-11 place-items-center rounded-xl bg-gradient-to-br from-[#c9a227] to-[#b08968] text-[#14110d] shadow-lg transition-transform group-hover:scale-105">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
              <rect x="3" y="4" width="18" height="16" rx="1.5" />
              <line x1="12" y1="4" x2="12" y2="20" />
              <line x1="3" y1="12" x2="21" y2="12" />
            </svg>
          </span>
          <span className="hidden sm:block text-left leading-tight">
            <span className="block font-display text-lg font-semibold text-white">Easyhome</span>
            <span className="block text-[10px] uppercase tracking-[0.35em] text-[#c9a227]">Cabinetry</span>
          </span>
        </button>

        <ul className="hidden items-center gap-8 lg:flex">
          {LINKS.map((l) => (
            <li key={l.href}>
              <button
                onClick={() => go(l.href)}
                className={`nav-link text-sm font-medium transition-colors ${
                  active === l.href ? 'text-[#e6c860] active' : 'text-stone-200 hover:text-white'
                }`}
              >
                {l.label}
              </button>
            </li>
          ))}
        </ul>

        <div className="hidden lg:block">
          <a
            href="tel:0451600512"
            className="group inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-[#c9a227] to-[#b08968] px-5 py-2.5 text-sm font-semibold text-[#14110d] shadow-lg shadow-[#c9a227]/20 transition-all hover:shadow-[#c9a227]/40 hover:-translate-y-0.5"
          >
            <Phone size={16} className="transition-transform group-hover:rotate-12" />
            0451 600 512
          </a>
        </div>

        <button
          className="lg:hidden grid h-10 w-10 place-items-center rounded-lg text-white hover:bg-white/10 focus-ring"
          onClick={() => setOpen((v) => !v)}
          aria-label="Toggle menu"
          aria-expanded={open}
        >
          {open ? <X size={22} /> : <Menu size={22} />}
        </button>
      </nav>

      {/* Mobile menu */}
      <div
        className={`lg:hidden overflow-hidden transition-[max-height,opacity] duration-300 ${
          open ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'
        }`}
      >
        <ul className="mx-4 mt-3 space-y-1 rounded-2xl bg-[#1c1917]/95 p-4 backdrop-blur-xl">
          {LINKS.map((l) => (
            <li key={l.href}>
              <button
                onClick={() => go(l.href)}
                className={`block w-full rounded-lg px-4 py-3 text-left text-base font-medium transition-colors ${
                  active === l.href ? 'bg-[#c9a227]/15 text-[#e6c860]' : 'text-stone-200 hover:bg-white/5'
                }`}
              >
                {l.label}
              </button>
            </li>
          ))}
          <li className="pt-2">
            <a
              href="tel:0451600512"
              className="flex items-center justify-center gap-2 rounded-full bg-gradient-to-r from-[#c9a227] to-[#b08968] px-5 py-3 text-sm font-semibold text-[#14110d]"
            >
              <Phone size={16} /> 0451 600 512
            </a>
          </li>
        </ul>
      </div>
    </header>
  );
}

import { useState } from 'react';
import { Loader2, Send, CheckCircle2, AlertCircle } from 'lucide-react';
import { supabase } from '../supabaseClient';

const SERVICES = [
  { value: 'kitchen', label: 'Custom Kitchen' },
  { value: 'wardrobe', label: 'Walk-in Wardrobe' },
  { value: 'tv_wall', label: 'TV Wall Unit' },
  { value: 'other', label: 'Other Cabinetry' },
];

type Status = 'idle' | 'loading' | 'success' | 'error';

export default function QuoteForm() {
  const [form, setForm] = useState({ name: '', email: '', phone: '', service: '', message: '' });
  const [status, setStatus] = useState<Status>('idle');
  const [errMsg, setErrMsg] = useState('');

  const update = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) =>
    setForm((f) => ({ ...f, [k]: e.target.value }));

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (status === 'loading') return;
    setStatus('loading');
    setErrMsg('');

    if (!form.name.trim() || !form.email.trim() || !form.phone.trim() || !form.service || !form.message.trim()) {
      setStatus('error');
      setErrMsg('Please fill in all fields before submitting.');
      return;
    }

    const { error } = await supabase.from('quotes').insert({
      name: form.name.trim(),
      email: form.email.trim(),
      phone: form.phone.trim(),
      service: form.service,
      message: form.message.trim(),
    });

    if (error) {
      setStatus('error');
      setErrMsg('Something went wrong sending your request. Please try calling us on 0451 600 512.');
      return;
    }

    setStatus('success');
    setForm({ name: '', email: '', phone: '', service: '', message: '' });
  };

  return (
    <section id="quote" className="relative overflow-hidden bg-[#14110d] py-24 sm:py-32">
      <div className="pointer-events-none absolute -left-20 top-1/4 h-80 w-80 rounded-full bg-[#c9a227]/15 blur-3xl" />
      <div className="pointer-events-none absolute -right-20 bottom-0 h-96 w-96 rounded-full bg-[#b08968]/10 blur-3xl" />

      <div className="relative mx-auto max-w-6xl px-5 sm:px-8">
        <div className="grid gap-12 lg:grid-cols-[0.85fr_1.15fr] lg:gap-16">
          {/* Left: pitch */}
          <div className="reveal">
            <span className="text-xs font-bold uppercase tracking-[0.3em] text-[#c9a227]">Get a Quote</span>
            <h2 className="mt-3 font-display text-4xl font-semibold leading-tight text-white sm:text-5xl">
              Tell us about your project
            </h2>
            <p className="mt-5 text-stone-400">
              Share a few details and Rohit will get back to you with a free, no-obligation quote.
              Most enquiries are answered within one business day.
            </p>

            <ul className="mt-8 space-y-4 text-sm">
              {[
                'Free on-site measure & quote',
                'Honest, itemised pricing — no surprises',
                'Clear timeline before we start',
              ].map((t) => (
                <li key={t} className="flex items-center gap-3 text-stone-200">
                  <CheckCircle2 size={18} className="shrink-0 text-[#e6c860]" />
                  {t}
                </li>
              ))}
            </ul>

            <div className="mt-10 rounded-2xl border border-white/10 bg-white/[0.03] p-5">
              <p className="text-xs uppercase tracking-wider text-stone-500">Prefer to talk?</p>
              <a href="tel:0451600512" className="mt-1 block font-display text-2xl font-semibold text-[#e6c860] hover:text-white">
                0451 600 512
              </a>
              <p className="mt-1 text-sm text-stone-400">Open · Closes 3:30 pm</p>
            </div>
          </div>

          {/* Right: form */}
          <div className="reveal rounded-3xl bg-white p-6 shadow-2xl sm:p-8">
            {status === 'success' ? (
              <div className="flex min-h-[420px] flex-col items-center justify-center text-center">
                <span className="grid h-16 w-16 place-items-center rounded-full bg-green-100 text-green-600">
                  <CheckCircle2 size={32} />
                </span>
                <h3 className="mt-5 font-display text-2xl font-semibold text-[#1c1917]">Request received!</h3>
                <p className="mt-2 max-w-sm text-stone-600">
                  Thanks for reaching out. Rohit will be in touch shortly to discuss your project.
                </p>
                <button
                  onClick={() => setStatus('idle')}
                  className="mt-6 rounded-full bg-[#14110d] px-6 py-3 text-sm font-semibold text-white transition-colors hover:bg-[#6f4e37]"
                >
                  Send another request
                </button>
              </div>
            ) : (
              <form onSubmit={submit} className="space-y-5" noValidate>
                <div className="grid gap-5 sm:grid-cols-2">
                  <Field label="Full name" required>
                    <input
                      type="text"
                      value={form.name}
                      onChange={update('name')}
                      placeholder="Jane Smith"
                      className={inputCls}
                    />
                  </Field>
                  <Field label="Phone" required>
                    <input
                      type="tel"
                      value={form.phone}
                      onChange={update('phone')}
                      placeholder="04xx xxx xxx"
                      className={inputCls}
                    />
                  </Field>
                </div>

                <Field label="Email" required>
                  <input
                    type="email"
                    value={form.email}
                    onChange={update('email')}
                    placeholder="jane@email.com"
                    className={inputCls}
                  />
                </Field>

                <Field label="Service needed" required>
                  <select value={form.service} onChange={update('service')} className={inputCls}>
                    <option value="">Select a service…</option>
                    {SERVICES.map((s) => (
                      <option key={s.value} value={s.value}>{s.label}</option>
                    ))}
                  </select>
                </Field>

                <Field label="Project details" required>
                  <textarea
                    value={form.message}
                    onChange={update('message')}
                    rows={4}
                    placeholder="Tell us about the space, approximate size, timeline, etc."
                    className={`${inputCls} resize-none`}
                  />
                </Field>

                {status === 'error' && (
                  <div className="flex items-start gap-2 rounded-xl bg-red-50 p-3 text-sm text-red-700">
                    <AlertCircle size={18} className="mt-0.5 shrink-0" />
                    <span>{errMsg}</span>
                  </div>
                )}

                <button
                  type="submit"
                  disabled={status === 'loading'}
                  className="group flex w-full items-center justify-center gap-2 rounded-full bg-gradient-to-r from-[#c9a227] to-[#b08968] px-7 py-4 text-base font-semibold text-[#14110d] shadow-lg transition-all hover:shadow-xl disabled:cursor-not-allowed disabled:opacity-70"
                >
                  {status === 'loading' ? (
                    <>
                      <Loader2 size={18} className="animate-spin" /> Sending…
                    </>
                  ) : (
                    <>
                      Send my quote request
                      <Send size={17} className="transition-transform group-hover:translate-x-1" />
                    </>
                  )}
                </button>
                <p className="text-center text-xs text-stone-400">
                  By submitting, you agree to be contacted about your enquiry.
                </p>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}

const inputCls =
  'w-full rounded-xl border border-stone-200 bg-stone-50 px-4 py-3 text-sm text-[#1c1917] placeholder:text-stone-400 transition-all focus:border-[#c9a227] focus:bg-white focus:ring-2 focus:ring-[#c9a227]/20 outline-none';

function Field({ label, required, children }: { label: string; required?: boolean; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-stone-600">
        {label} {required && <span className="text-[#c9a227]">*</span>}
      </span>
      {children}
    </label>
  );
}

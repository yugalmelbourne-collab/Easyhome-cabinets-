import { Star, Quote } from 'lucide-react';

type Review = {
  name: string;
  meta: string;
  text: string;
  highlight?: boolean;
};

const REVIEWS: Review[] = [
  {
    name: 'Ankita Suresh',
    meta: '5 reviews · a week ago',
    text: 'Rohit and team did an amazing job with our walk in wardrobe! Would highly recommend.',
    highlight: true,
  },
  {
    name: 'amanjot mavi',
    meta: '17 reviews · a week ago',
    text: 'Highly recommend them, did an amazing job without any hassle 👌🏻 highly experienced guys with excellent knowledge.',
  },
  {
    name: 'Nasrat',
    meta: '1 review · 1 photo · a week ago',
    text: 'Excellent work, great price and timing is perfect. Highly recommended.',
  },
  {
    name: 'Verified Customer',
    meta: 'Google Review',
    text: 'We highly recommend Rohit Paaji to anyone looking for quality carpentry work.',
  },
  {
    name: 'Verified Customer',
    meta: 'Google Review',
    text: "I couldn't be happier with the work EASYHOME guys have done at my home.",
  },
];

export default function Reviews() {
  return (
    <section id="reviews" className="relative overflow-hidden bg-[#faf8f5] py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <div className="reveal mx-auto mb-14 max-w-2xl text-center">
          <span className="text-xs font-bold uppercase tracking-[0.3em] text-[#b08968]">Reviews</span>
          <h2 className="mt-3 font-display text-4xl font-semibold text-[#1c1917] sm:text-5xl">
            Loved by homeowners across Tarneit
          </h2>
          <div className="mt-5 inline-flex items-center gap-3 rounded-full bg-white px-5 py-2.5 shadow-sm">
            <div className="flex">
              {[...Array(5)].map((_, i) => (
                <Star key={i} size={18} className="fill-[#e6c860] text-[#e6c860]" />
              ))}
            </div>
            <span className="text-sm font-semibold text-[#1c1917]">5.0</span>
            <span className="text-sm text-stone-500">· 8 Google reviews</span>
          </div>
        </div>

        {/* Masonry-ish columns */}
        <div className="columns-1 gap-5 sm:columns-2 lg:columns-3 [&>*]:mb-5">
          {REVIEWS.map((r, i) => (
            <figure
              key={r.name + i}
              className={`reveal break-inside-avoid rounded-3xl p-6 shadow-sm transition-all hover:shadow-lg ${
                r.highlight
                  ? 'bg-[#14110d] text-white'
                  : 'bg-white text-[#1c1917]'
              }`}
              style={{ transitionDelay: `${i * 70}ms` }}
            >
              <Quote
                size={28}
                className={r.highlight ? 'text-[#c9a227]' : 'text-[#b08968]'}
              />
              <blockquote className="mt-3 text-[15px] leading-relaxed">
                "{r.text}"
              </blockquote>
              <figcaption className="mt-5 flex items-center gap-3">
                <span
                  className={`grid h-10 w-10 place-items-center rounded-full font-display text-sm font-semibold ${
                    r.highlight ? 'bg-[#c9a227] text-[#14110d]' : 'bg-[#f5efe6] text-[#6f4e37]'
                  }`}
                >
                  {r.name.charAt(0).toUpperCase()}
                </span>
                <span>
                  <span className="block text-sm font-semibold">{r.name}</span>
                  <span className={`block text-xs ${r.highlight ? 'text-stone-400' : 'text-stone-500'}`}>
                    {r.meta}
                  </span>
                </span>
              </figcaption>
            </figure>
          ))}
        </div>

        <div className="reveal mt-12 text-center">
          <a
            href="https://www.google.com/maps/search/?api=1&query=Easyhome+Cabinetry+36+Reunion+Parade+Tarneit+VIC+3029"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 rounded-full bg-[#14110d] px-7 py-3.5 text-sm font-semibold text-white transition-all hover:bg-[#6f4e37] hover:-translate-y-0.5"
          >
            <Star size={16} className="fill-[#e6c860] text-[#e6c860]" />
            Read all reviews on Google
          </a>
        </div>
      </div>
    </section>
  );
}

import { UtensilsCrossed, Shirt, Tv, Sofa, Sparkles, Check } from 'lucide-react';
import type { LucideIcon } from 'lucide-react';

type Service = {
  icon: LucideIcon;
  title: string;
  desc: string;
  points: string[];
};

const SERVICES: Service[] = [
  {
    icon: UtensilsCrossed,
    title: 'Custom Kitchens',
    desc: 'Made-to-measure kitchens built around how you cook, entertain and live.',
    points: ['Soft-close hardware', 'Stone / timber benchtops', 'Premium hinges & rails'],
  },
  {
    icon: Shirt,
    title: 'Walk-in Wardrobes',
    desc: 'Bespoke wardrobe internals that maximise every millimetre of storage.',
    points: ['Adjustable shelving', 'Integrated drawer systems', 'Custom hanging space'],
  },
  {
    icon: Tv,
    title: 'TV Wall Units',
    desc: 'Statement entertainment walls with hidden cabling and ambient lighting.',
    points: ['Concealed cable management', 'Floating & built-in options', 'LED accent lighting'],
  },
  {
    icon: Sofa,
    title: 'Custom Cabinetry',
    desc: 'Vanities, bookshelves, laundry units — anything built from cabinetry.',
    points: ['Made to your dimensions', 'Match existing joinery', 'Any finish or stain'],
  },
];

export default function Services() {
  return (
    <section id="services" className="relative overflow-hidden bg-[#14110d] py-24 sm:py-32">
      <div className="pointer-events-none absolute right-0 top-0 h-96 w-96 rounded-full bg-[#c9a227]/10 blur-3xl" />
      <div className="pointer-events-none absolute bottom-0 left-0 h-80 w-80 rounded-full bg-[#b08968]/10 blur-3xl" />

      <div className="relative mx-auto max-w-7xl px-5 sm:px-8">
        <div className="reveal mb-14 max-w-2xl">
          <span className="text-xs font-bold uppercase tracking-[0.3em] text-[#c9a227]">What We Build</span>
          <h2 className="mt-3 font-display text-4xl font-semibold text-white sm:text-5xl">
            Services tailored to your space
          </h2>
          <p className="mt-4 text-stone-400">
            From a single wardrobe to a full home fit-out, every piece is designed,
            manufactured and installed by our team — no subcontracting, no shortcuts.
          </p>
        </div>

        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {SERVICES.map((s, i) => (
            <div
              key={s.title}
              className="reveal group rounded-3xl border border-white/10 bg-white/[0.03] p-7 backdrop-blur-sm transition-all duration-300 hover:-translate-y-2 hover:border-[#c9a227]/40 hover:bg-white/[0.06]"
              style={{ transitionDelay: `${i * 90}ms` }}
            >
              <span className="mb-5 grid h-14 w-14 place-items-center rounded-2xl bg-gradient-to-br from-[#c9a227] to-[#b08968] text-[#14110d] shadow-lg transition-transform group-hover:scale-110 group-hover:rotate-3">
                <s.icon size={26} />
              </span>
              <h3 className="font-display text-xl font-semibold text-white">{s.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-stone-400">{s.desc}</p>
              <ul className="mt-5 space-y-2">
                {s.points.map((pt) => (
                  <li key={pt} className="flex items-center gap-2 text-sm text-stone-300">
                    <Check size={15} className="shrink-0 text-[#e6c860]" />
                    {pt}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="reveal mt-12 flex flex-wrap items-center justify-center gap-3 rounded-2xl border border-[#c9a227]/20 bg-[#c9a227]/5 px-6 py-5 text-center">
          <Sparkles size={18} className="text-[#e6c860]" />
          <p className="text-sm text-stone-200">
            Not sure what you need? We offer free on-site measure & quote across Melbourne's west.
          </p>
          <button
            onClick={() => document.querySelector('#quote')?.scrollIntoView({ behavior: 'smooth' })}
            className="ml-1 rounded-full bg-[#c9a227] px-4 py-1.5 text-xs font-semibold text-[#14110d] transition-colors hover:bg-[#e6c860]"
          >
            Book a measure →
          </button>
        </div>
      </div>
    </section>
  );
}

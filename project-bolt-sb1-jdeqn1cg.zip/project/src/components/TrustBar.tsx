import { Hammer, Ruler, Clock, BadgeCheck } from 'lucide-react';

const STATS = [
  { icon: BadgeCheck, value: '5.0★', label: 'Google Rating' },
  { icon: Hammer, value: '8+', label: '5-Star Reviews' },
  { icon: Ruler, value: 'Custom', label: 'Made to Measure' },
  { icon: Clock, value: 'On Time', label: 'Delivery, Every Job' },
];

export default function TrustBar() {
  return (
    <section className="relative -mt-px bg-[#f5efe6] py-14">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-4 lg:gap-6">
          {STATS.map((s, i) => (
            <div
              key={s.label}
              className="reveal group flex flex-col items-center rounded-2xl border border-[#b08968]/15 bg-white p-6 text-center shadow-sm transition-all hover:-translate-y-1 hover:shadow-xl hover:shadow-[#b08968]/10"
              style={{ transitionDelay: `${i * 80}ms` }}
            >
              <span className="mb-3 grid h-12 w-12 place-items-center rounded-xl bg-gradient-to-br from-[#c9a227]/15 to-[#b08968]/15 text-[#6f4e37] transition-transform group-hover:scale-110">
                <s.icon size={22} />
              </span>
              <span className="font-display text-2xl font-semibold text-[#1c1917]">{s.value}</span>
              <span className="mt-1 text-xs font-medium uppercase tracking-wider text-stone-500">{s.label}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

import { ArrowUpRight } from 'lucide-react';

const PROJECTS = [
  {
    title: 'Custom Kitchen',
    tag: 'Kitchen',
    img: '/images/kitchen/WhatsApp_Image_2026-07-14_at_11.13.44_AM.jpeg',
    desc: 'Handcrafted cabinetry with soft-close hardware and a seamless stone benchtop finish.',
    span: 'lg:col-span-2 lg:row-span-2',
  },
  {
    title: 'Walk-in Wardrobe',
    tag: 'Wardrobe',
    img: '/images/wardrobe/WhatsApp_Image_2026-07-14_at_11.13.43_AM.jpeg',
    desc: 'Custom shelving, drawers and hanging space tailored to your room.',
    span: '',
  },
  {
    title: 'TV Wall Unit',
    tag: 'Entertainment',
    img: '/images/tv-wall/WhatsApp_Image_2026-07-14_at_11.13.43_AM_(1).jpeg',
    desc: 'A statement media wall with integrated storage and ambient lighting.',
    span: '',
  },
  {
    title: 'Kitchen Overview',
    tag: 'Kitchen',
    img: '/images/kitchen-overview/WhatsApp_Image_2026-07-14_at_11.13.44_AM_(1).jpeg',
    desc: 'A full view of a finished kitchen — cohesion from cabinetry to splashback.',
    span: 'lg:col-span-2',
  },
];

export default function Work() {
  return (
    <section id="work" className="bg-[#faf8f5] py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <div className="reveal mx-auto mb-14 max-w-2xl text-center">
          <span className="text-xs font-bold uppercase tracking-[0.3em] text-[#b08968]">Our Work</span>
          <h2 className="mt-3 font-display text-4xl font-semibold text-[#1c1917] sm:text-5xl">
            Craftsmanship that speaks for itself
          </h2>
          <p className="mt-4 text-stone-600">
            Every project is built to measure — from the first cut to the final fit-off.
            Here is a selection of recent work delivered across Melbourne.
          </p>
        </div>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4 lg:gap-5 lg:auto-rows-[280px]">
          {PROJECTS.map((p, i) => (
            <article
              key={p.title}
              className={`work-card reveal group relative overflow-hidden rounded-3xl bg-[#14110d] shadow-lg ${p.span}`}
              style={{ transitionDelay: `${i * 100}ms` }}
            >
              <img
                src={p.img}
                alt={p.title}
                loading="lazy"
                className="h-full w-full object-cover opacity-80 transition-opacity duration-500 group-hover:opacity-60"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#14110d] via-[#14110d]/30 to-transparent" />

              <span className="absolute left-4 top-4 rounded-full bg-[#c9a227]/90 px-3 py-1 text-[11px] font-semibold uppercase tracking-wider text-[#14110d]">
                {p.tag}
              </span>

              <div className="absolute inset-x-0 bottom-0 p-5">
                <div className="flex items-end justify-between gap-3">
                  <div>
                    <h3 className="font-display text-xl font-semibold text-white">{p.title}</h3>
                    <p className="mt-1 max-w-xs text-sm leading-snug text-stone-300 opacity-0 transition-all duration-500 group-hover:opacity-100">
                      {p.desc}
                    </p>
                  </div>
                  <span className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-white/10 text-white transition-all group-hover:bg-[#c9a227] group-hover:text-[#14110d]">
                    <ArrowUpRight size={16} />
                  </span>
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

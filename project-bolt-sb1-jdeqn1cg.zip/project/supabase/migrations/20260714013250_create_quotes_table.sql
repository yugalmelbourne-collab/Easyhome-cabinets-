/*
# Create quotes table for Easyhome Cabinetry

1. New Tables
- `quotes`
  - `id` (uuid, primary key)
  - `name` (text, not null) - customer full name
  - `email` (text, not null) - customer email
  - `phone` (text, not null) - customer phone number
  - `service` (text, not null) - service type: kitchen, wardrobe, tv_wall, other
  - `message` (text, not null) - project details / message
  - `created_at` (timestamptz, default now())

2. Security
- Enable RLS on `quotes`.
- Allow anon + authenticated INSERT (public form submission).
- No SELECT for anon (admin-only read via service role).
*/

CREATE TABLE IF NOT EXISTS quotes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email text NOT NULL,
  phone text NOT NULL,
  service text NOT NULL,
  message text NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE quotes ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_insert_quotes" ON quotes;
CREATE POLICY "anon_insert_quotes" ON quotes FOR INSERT
TO anon, authenticated WITH CHECK (true);
